<?php 
	/*
	*	Author Beycan Beycanov 
	*/
	
	define('URL','https://example.com/');					  	// CHANGE YOUR SITE NAME	
	define('APP_ID','app-id-here');						  		// CHANGE YOUR FACEBOOK APP ID
	define('SECRET_KEY','app-secret-here');						// CHANGE YOUR FACEBOOK APP secret key
	define('GRAPH_VERSIONS','v2.2');							// CHANGE YOUR FACEBOOK API GRAPH VERSIONS
?>